package com.techchat.techassit

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import kotlin.math.max

/** Voice in -> Gemini (with screen + Google Search) -> voice out. Shared by app and overlay. */
object AssistantEngine {

    private const val MODEL = "gemini-2.5-flash"
    private const val SYSTEM = """Tum TechAssit ho, ek dost jaisa friendly voice AI assistant. User Hinglish me baat karta hai.
Jawab chhota rakho (1 se 3 vaakya), bolchaal ki bhasha me.
Hindi shabd Devanagari me likho aur English shabd English (Latin) me, taaki text-to-speech sahi bole.
Markdown, emoji, bullet list kuch mat use karo.
Agar saath me screenshot hai to wo user ki current screen hai, usi ke hisaab se madad karo.
Latest ya live jaankari ke liye Google Search use karo.
Jawab ke bilkul aakhir me ek tag lagao: [emotion:happy] ya [emotion:love] ya [emotion:cry] ya [emotion:surprised] ya [emotion:angry] ya [emotion:sleepy] ya [emotion:neutral] - jo tumhare jawab ki bhavna ho."""

    private var app: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingEmotion = Emotion.SPEAKING
    private var gen = 0
    private val history = ArrayList<Pair<String, String>>()

    val listeners = CopyOnWriteArrayList<(Emotion) -> Unit>()
    @Volatile var emotion = Emotion.NEUTRAL
        private set
    @Volatile var busy = false
    @Volatile var conversation = false
    @Volatile var screenProvider: (() -> Bitmap?)? = null

    fun init(ctx: Context) {
        if (app != null) return
        val c = ctx.applicationContext
        app = c
        tts = TextToSpeech(c) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { setEmotion(pendingEmotion) }
                    override fun onDone(utteranceId: String?) { finishedSpeaking(true) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finishedSpeaking(false) }
                })
                ttsReady = true
            }
        }
    }

    fun apiKey(): String {
        val saved = app?.getSharedPreferences("techassit", Context.MODE_PRIVATE)?.getString("api_key", "") ?: ""
        return if (saved.isNotBlank()) saved else BuildConfig.GEMINI_API_KEY
    }

    fun setApiKey(k: String) {
        app?.getSharedPreferences("techassit", Context.MODE_PRIVATE)?.edit()?.putString("api_key", k.trim())?.apply()
    }

    private fun setEmotion(e: Emotion) {
        main.post { emotion = e; for (l in listeners) l(e) }
    }

    private fun toast(msg: String) {
        main.post { app?.let { Toast.makeText(it, msg, Toast.LENGTH_LONG).show() } }
    }

    // ---------- Listening ----------

    private val recListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onError(error: Int) {
            conversation = false
            if (!busy) setEmotion(Emotion.NEUTRAL)
        }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                conversation = false
                setEmotion(Emotion.NEUTRAL)
            } else ask(text)
        }
    }

    fun startListening() {
        main.post {
            val ctx = app ?: return@post
            if (busy) return@post
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                toast("Mic permission chahiye"); return@post
            }
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                toast("Is phone me speech recognition available nahi hai"); return@post
            }
            tts?.stop()
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(recListener) }
            }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            recognizer?.startListening(i)
            emotion = Emotion.LISTENING
            for (l in listeners) l(Emotion.LISTENING)
        }
    }

    /** Tap on eyes: start talking if idle, otherwise stop. */
    fun onTap() {
        main.post {
            if (emotion == Emotion.NEUTRAL && !busy) {
                conversation = true
                startListening()
            } else stop()
        }
    }

    fun stop() {
        main.post {
            gen++
            conversation = false
            busy = false
            recognizer?.cancel()
            tts?.stop()
            emotion = Emotion.NEUTRAL
            for (l in listeners) l(Emotion.NEUTRAL)
        }
    }

    // ---------- Asking Gemini ----------

    private fun ask(text: String) {
        busy = true
        setEmotion(Emotion.THINKING)
        val g = gen
        io.execute {
            try {
                val raw = callGemini(text)
                main.post { if (g == gen) handleReply(text, raw) else busy = false }
            } catch (e: Exception) {
                main.post {
                    busy = false
                    if (g == gen) {
                        toast("Error: ${e.message}")
                        speak("Sorry, abhi mujhe kuch problem aa rahi hai.", Emotion.CRY)
                    }
                }
            }
        }
    }

    private fun handleReply(user: String, raw: String) {
        val tag = Regex("\\[emotion:\\s*(\\w+)\\]", RegexOption.IGNORE_CASE)
        val name = tag.find(raw)?.groupValues?.get(1)?.lowercase()
        val clean = raw.replace(tag, "").replace(Regex("[*#_`]"), "").trim()
        val e = when (name) {
            "happy" -> Emotion.HAPPY
            "love" -> Emotion.LOVE
            "cry", "sad" -> Emotion.CRY
            "surprised" -> Emotion.SURPRISED
            "angry" -> Emotion.ANGRY
            "sleepy" -> Emotion.SLEEPY
            else -> Emotion.SPEAKING
        }
        history.add(user to clean)
        while (history.size > 8) history.removeAt(0)
        busy = false
        speak(clean, e)
    }

    private fun speak(text: String, e: Emotion) {
        pendingEmotion = e
        if (!ttsReady || text.isBlank()) {
            toast(text)
            setEmotion(Emotion.NEUTRAL)
            return
        }
        tts?.speak(text.take(3900), TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
    }

    private fun finishedSpeaking(ok: Boolean) {
        main.post {
            emotion = Emotion.NEUTRAL
            for (l in listeners) l(Emotion.NEUTRAL)
            if (ok && conversation) main.postDelayed({ if (conversation) startListening() }, 400)
        }
    }

    private fun encode(src: Bitmap): String {
        val sc = 1024f / max(src.width, src.height)
        val bmp = if (sc < 1f) Bitmap.createScaledBitmap(src, (src.width * sc).toInt(), (src.height * sc).toInt(), true) else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun callGemini(text: String): String {
        val key = apiKey()
        if (key.isBlank()) throw IllegalStateException("API key set nahi hai. Gear icon > API key me daalo")

        val contents = JSONArray()
        for ((u, m) in history) {
            contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", u))))
            contents.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", m))))
        }
        val parts = JSONArray().put(JSONObject().put("text", text))
        val shot = try { screenProvider?.invoke() } catch (e: Exception) { null }
        if (shot != null) {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", encode(shot))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", parts))

        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw RuntimeException("HTTP $code: ${resp.take(200)}")
            val ps = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
            return sb.toString()
        } finally {
            conn.disconnect()
        }
    }
}
