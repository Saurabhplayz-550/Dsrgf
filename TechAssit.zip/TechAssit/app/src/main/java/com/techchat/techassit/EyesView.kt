package com.techchat.techassit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class Emotion { NEUTRAL, HAPPY, LOVE, CRY, SURPRISED, ANGRY, SLEEPY, THINKING, LISTENING, SPEAKING }

/** LED-dot matrix style animated eyes. */
class EyesView(context: Context) : View(context) {

    var emotion: Emotion = Emotion.NEUTRAL
    var showGrid = true
    var cols = 72
        set(v) { field = v; mask = null }

    private val startTime = SystemClock.uptimeMillis()
    private var mask: Bitmap? = null
    private var maskCanvas: Canvas? = null
    private var pixels = IntArray(0)
    private var rows = 0
    private var cell = 1f

    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 0, 0, 16) }
    private val path = Path()
    private val lid = Path()
    private val rect = RectF()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        mask = null
    }

    private fun ensureMask() {
        if (mask == null && width > 0 && height > 0) {
            cell = width.toFloat() / cols
            rows = max(1, (height / cell).toInt())
            val b = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)
            mask = b
            maskCanvas = Canvas(b)
            pixels = IntArray(cols * rows)
        }
    }

    private fun colorFor(e: Emotion): Int = when (e) {
        Emotion.LOVE -> 0xFFFF2233.toInt()
        Emotion.ANGRY -> 0xFFFF4422.toInt()
        Emotion.CRY -> 0xFF5AB0FF.toInt()
        Emotion.HAPPY -> 0xFF3DE8FF.toInt()
        else -> 0xFF2D8CFF.toInt()
    }

    private fun blink(t: Float): Float {
        val p = t % 4.3f
        return if (p < 0.2f) abs(p - 0.1f) / 0.1f else 1f
    }

    override fun onDraw(canvas: Canvas) {
        ensureMask()
        val m = mask ?: return
        val c = maskCanvas ?: return

        if (!showGrid) {
            canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), height * 0.25f, height * 0.25f, bgPaint)
        }

        val t = (SystemClock.uptimeMillis() - startTime) / 1000f
        m.eraseColor(Color.TRANSPARENT)
        val w = cols.toFloat()
        val h = rows.toFloat()
        val r = min(w * 0.14f, h * 0.3f)
        val cy = h * 0.5f
        drawEye(c, w * 0.3f, cy, r, t, 1)
        drawEye(c, w * 0.7f, cy, r, t, -1)

        m.getPixels(pixels, 0, cols, 0, 0, cols, rows)
        val color = colorFor(emotion)
        for (y in 0 until rows) {
            for (x in 0 until cols) {
                val a = pixels[y * cols + x] ushr 24
                val px = x * cell + cell / 2
                val py = y * cell + cell / 2
                if (a > 30) {
                    dotPaint.color = color
                    dotPaint.alpha = 45
                    canvas.drawCircle(px, py, cell * 0.95f, dotPaint)
                    dotPaint.alpha = min(255, a + 30)
                    canvas.drawCircle(px, py, cell * 0.4f, dotPaint)
                } else if (showGrid) {
                    dotPaint.color = color
                    dotPaint.alpha = 22
                    canvas.drawCircle(px, py, cell * 0.18f, dotPaint)
                }
            }
        }
        postInvalidateOnAnimation()
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float, r: Float, t: Float, dir: Int) {
        when (emotion) {
            Emotion.HAPPY -> {
                strokePaint.strokeWidth = r * 0.4f
                val bob = sin(t * 5f) * r * 0.05f
                rect.set(cx - r * 0.85f, cy - r * 0.2f + bob, cx + r * 0.85f, cy + r * 1.3f + bob)
                c.drawArc(rect, 200f, 140f, false, strokePaint)
            }
            Emotion.LOVE -> heart(c, cx, cy, r * (1.05f + 0.1f * sin(t * 8f)))
            Emotion.SLEEPY -> {
                strokePaint.strokeWidth = r * 0.3f
                val b = sin(t * 2f) * r * 0.05f
                c.drawLine(cx - r * 0.8f, cy + b, cx + r * 0.8f, cy + b, strokePaint)
            }
            else -> ringEye(c, cx, cy, r, t, dir)
        }
    }

    private fun ringEye(c: Canvas, cx: Float, cy: Float, r: Float, t: Float, dir: Int) {
        var rad = r
        var hole = 0.45f
        var lx = 0f
        var ly = 0f
        var open = blink(t)
        var dy = 0f
        when (emotion) {
            Emotion.LISTENING -> { rad = r * (1f + 0.05f * sin(t * 6f)); hole = 0.45f + 0.08f * sin(t * 6f) }
            Emotion.SPEAKING -> rad = r * (1f + 0.07f * abs(sin(t * 9f)))
            Emotion.SURPRISED -> { rad = r * 1.15f; hole = 0.3f; open = 1f }
            Emotion.THINKING -> { lx = sin(t * 1.6f) * 0.9f; ly = -0.5f }
            Emotion.CRY -> { open = min(open, 0.8f); dy = r * 0.1f; hole = 0.4f }
            else -> {}
        }
        val ey = cy + dy
        c.save()
        c.scale(1f, max(open, 0.05f), cx, ey)
        if (emotion == Emotion.ANGRY) {
            lid.reset()
            lid.moveTo(cx - dir * r * 1.3f, cy - r * 1.3f)
            lid.lineTo(cx + dir * r * 1.3f, cy - r * 1.3f)
            lid.lineTo(cx + dir * r * 1.3f, cy + r * 0.05f)
            lid.lineTo(cx - dir * r * 1.3f, cy - r * 0.75f)
            lid.close()
            c.clipOutPath(lid)
        }
        path.reset()
        path.fillType = Path.FillType.EVEN_ODD
        path.addCircle(cx, ey, rad, Path.Direction.CW)
        path.addCircle(cx + lx * rad * 0.3f, ey + ly * rad * 0.3f, rad * hole, Path.Direction.CW)
        c.drawPath(path, maskPaint)
        c.restore()

        if (emotion == Emotion.CRY) {
            for (i in 0..1) {
                val ph = (t * 0.7f + i * 0.5f) % 1f
                val tx = cx + (if (i == 0) -0.45f else 0.45f) * r
                val ty = cy + r * 0.75f + ph * r * 1.4f
                maskPaint.alpha = (255 * (1f - ph)).toInt()
                c.drawOval(tx - r * 0.1f, ty - r * 0.16f, tx + r * 0.1f, ty + r * 0.16f, maskPaint)
            }
            maskPaint.alpha = 255
        }
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float) {
        path.reset()
        path.fillType = Path.FillType.WINDING
        path.moveTo(cx, cy + s * 0.95f)
        path.cubicTo(cx - s * 1.35f, cy + s * 0.1f, cx - s * 0.9f, cy - s * 0.95f, cx, cy - s * 0.35f)
        path.cubicTo(cx + s * 0.9f, cy - s * 0.95f, cx + s * 1.35f, cy + s * 0.1f, cx, cy + s * 0.95f)
        path.close()
        c.drawPath(path, maskPaint)
    }
}
