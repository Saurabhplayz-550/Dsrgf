package com.techchat.techassit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class Emotion { NEUTRAL, HAPPY, LOVE, CRY, SURPRISED, ANGRY, SLEEPY, THINKING, LISTENING, SPEAKING }

/** LED-dot matrix eyes with bloom glow. */
class EyesView(context: Context) : View(context) {

    var emotion: Emotion = Emotion.NEUTRAL
    var showGrid = true
    var cols = 110
        set(v) { field = v; mask = null }

    private val startTime = SystemClock.uptimeMillis()
    private var mask: Bitmap? = null
    private var maskCanvas: Canvas? = null
    private var g1: Bitmap? = null
    private var g2: Bitmap? = null
    private var g1c: Canvas? = null
    private var g2c: Canvas? = null
    private var pixels = IntArray(0)
    private var rows = 0
    private var cell = 1f

    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val filterPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val glowPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 0, 0, 16) }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.argb(200, 60, 200, 255)
    }
    private val path = Path()
    private val lid = Path()
    private val rect = RectF()
    private val dst = RectF()
    private var glowColor = 0

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        mask = null
    }

    private fun ensureMask() {
        if (mask == null && width > 0 && height > 0) {
            cell = width.toFloat() / cols
            rows = max(1, (height / cell).toInt())
            val b = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)
            mask = b
            maskCanvas = Canvas(b)
            pixels = IntArray(cols * rows)
            g1 = Bitmap.createBitmap(max(1, cols / 2), max(1, rows / 2), Bitmap.Config.ARGB_8888)
            g2 = Bitmap.createBitmap(max(1, cols / 5), max(1, rows / 5), Bitmap.Config.ARGB_8888)
            g1c = Canvas(g1!!)
            g2c = Canvas(g2!!)
        }
    }

    private fun colorFor(e: Emotion): Int = when (e) {
        Emotion.LOVE -> 0xFFFF1E32.toInt()
        Emotion.ANGRY -> 0xFFFF4020.toInt()
        Emotion.CRY -> 0xFF4FA8FF.toInt()
        Emotion.HAPPY -> 0xFF2FE0FF.toInt()
        else -> 0xFF1F7BFF.toInt()
    }

    private fun blend(c: Int, w: Float): Int {
        val r = (Color.red(c) + (255 - Color.red(c)) * w).toInt()
        val g = (Color.green(c) + (255 - Color.green(c)) * w).toInt()
        val b = (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
        return Color.rgb(r, g, b)
    }

    private fun blink(t: Float): Float {
        val p = t % 4.3f
        return if (p < 0.22f) {
            val x = p / 0.22f
            // smooth ease close/open
            val s = abs(x - 0.5f) * 2f
            s * s * (3f - 2f * s)
        } else 1f
    }

    override fun onDraw(canvas: Canvas) {
        ensureMask()
        val m = mask ?: return
        val c = maskCanvas ?: return

        if (!showGrid) {
            val rr = height * 0.25f
            canvas.drawRoundRect(2f, 2f, width - 2f, height - 2f, rr, rr, bgPaint)
            canvas.drawRoundRect(2f, 2f, width - 2f, height - 2f, rr, rr, borderPaint)
        }

        val t = (SystemClock.uptimeMillis() - startTime) / 1000f
        m.eraseColor(Color.TRANSPARENT)
        val w = cols.toFloat()
        val h = rows.toFloat()
        val r = min(w * 0.14f, h * 0.3f)
        val cy = h * 0.5f
        drawEye(c, w * 0.3f, cy, r, t, 1)
        drawEye(c, w * 0.7f, cy, r, t, -1)

        val color = colorFor(emotion)
        val core = blend(color, 0.45f)

        // bloom: blur by successive downscaling
        val a1 = g1!!; val a2 = g2!!
        a1.eraseColor(Color.TRANSPARENT)
        g1c!!.drawBitmap(m, null, Rect(0, 0, a1.width, a1.height), filterPaint)
        a2.eraseColor(Color.TRANSPARENT)
        g2c!!.drawBitmap(a1, null, Rect(0, 0, a2.width, a2.height), filterPaint)
        if (glowColor != color) {
            glowColor = color
            glowPaint.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
        }
        dst.set(0f, 0f, cols * cell, rows * cell)
        glowPaint.alpha = 255
        canvas.drawBitmap(a2, null, dst, glowPaint)
        glowPaint.alpha = 110
        canvas.drawBitmap(a1, null, dst, glowPaint)

        // LED dots
        m.getPixels(pixels, 0, cols, 0, 0, cols, rows)
        for (y in 0 until rows) {
            for (x in 0 until cols) {
                val a = pixels[y * cols + x] ushr 24
                val px = x * cell + cell / 2
                val py = y * cell + cell / 2
                if (a > 24) {
                    val k = a / 255f
                    dotPaint.color = if (a > 215) core else color
                    dotPaint.alpha = (110 + 145 * k).toInt()
                    canvas.drawCircle(px, py, cell * (0.24f + 0.22f * k), dotPaint)
                } else if (showGrid) {
                    dotPaint.color = color
                    dotPaint.alpha = 26
                    canvas.drawCircle(px, py, cell * 0.14f, dotPaint)
                }
            }
        }
        postInvalidateOnAnimation()
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float, r: Float, t: Float, dir: Int) {
        when (emotion) {
            Emotion.HAPPY -> {
                strokePaint.strokeWidth = r * 0.42f
                val bob = sin(t * 5f) * r * 0.05f
                rect.set(cx - r * 0.85f, cy - r * 0.2f + bob, cx + r * 0.85f, cy + r * 1.3f + bob)
                c.drawArc(rect, 200f, 140f, false, strokePaint)
            }
            Emotion.LOVE -> heart(c, cx, cy, r * (1.05f + 0.1f * sin(t * 8f)))
            Emotion.SLEEPY -> {
                strokePaint.strokeWidth = r * 0.3f
                val b = sin(t * 2f) * r * 0.05f
                c.drawLine(cx - r * 0.8f, cy + b, cx + r * 0.8f, cy + b, strokePaint)
            }
            else -> ringEye(c, cx, cy, r, t, dir)
        }
    }

    private fun ringEye(c: Canvas, cx: Float, cy: Float, r: Float, t: Float, dir: Int) {
        var rad = r
        var hole = 0.45f
        var lx = sin(t * 0.7f) * 0.35f   // idle look-around
        var ly = cos(t * 0.5f) * 0.2f
        var open = blink(t)
        var dy = 0f
        var spin = t * 0.6f
        when (emotion) {
            Emotion.LISTENING -> { rad = r * (1f + 0.05f * sin(t * 6f)); hole = 0.45f + 0.08f * sin(t * 6f); lx = 0f; ly = 0f; spin = t * 2f }
            Emotion.SPEAKING -> { rad = r * (1f + 0.07f * abs(sin(t * 9f))); lx = 0f; ly = 0f }
            Emotion.SURPRISED -> { rad = r * 1.15f; hole = 0.3f; open = 1f; lx = 0f; ly = 0f }
            Emotion.THINKING -> { lx = sin(t * 1.6f) * 0.9f; ly = -0.5f; spin = t * 3f }
            Emotion.CRY -> { open = min(open, 0.8f); dy = r * 0.1f; hole = 0.4f; lx = 0f; ly = 0.3f }
            else -> {}
        }
        val ey = cy + dy
        val hx = cx + lx * rad * 0.3f
        val hy = ey + ly * rad * 0.3f

        c.save()
        c.scale(1f, max(open, 0.05f), cx, ey)
        if (emotion == Emotion.ANGRY) {
            lid.reset()
            lid.moveTo(cx - dir * r * 1.3f, cy - r * 1.3f)
            lid.lineTo(cx + dir * r * 1.3f, cy - r * 1.3f)
            lid.lineTo(cx + dir * r * 1.3f, cy + r * 0.05f)
            lid.lineTo(cx - dir * r * 1.3f, cy - r * 0.75f)
            lid.close()
            c.clipOutPath(lid)
        }
        ringPaint.shader = RadialGradient(
            cx, ey, rad,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xB8FFFFFF.toInt()),
            floatArrayOf(0f, hole.coerceIn(0.1f, 0.85f), 1f), Shader.TileMode.CLAMP
        )
        path.reset()
        path.fillType = Path.FillType.EVEN_ODD
        path.addCircle(cx, ey, rad, Path.Direction.CW)
        path.addCircle(hx, hy, rad * hole, Path.Direction.CW)
        c.drawPath(path, ringPaint)

        // small highlights just inside the pupil, like the reference
        for (k in 0..3) {
            val ang = spin + Math.toRadians(45.0 + 90.0 * k).toFloat()
            val tx = hx + cos(ang) * rad * hole * 0.82f
            val ty = hy + sin(ang) * rad * hole * 0.82f
            maskPaint.alpha = 215
            c.drawCircle(tx, ty, r * 0.045f, maskPaint)
        }
        maskPaint.alpha = 255
        c.restore()

        if (emotion == Emotion.CRY) {
            for (i in 0..1) {
                val ph = (t * 0.7f + i * 0.5f) % 1f
                val tx = cx + (if (i == 0) -0.45f else 0.45f) * r
                val ty = cy + r * 0.75f + ph * r * 1.4f
                maskPaint.alpha = (255 * (1f - ph)).toInt()
                c.drawOval(tx - r * 0.1f, ty - r * 0.16f, tx + r * 0.1f, ty + r * 0.16f, maskPaint)
            }
            maskPaint.alpha = 255
        }
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float) {
        path.reset()
        path.fillType = Path.FillType.WINDING
        path.moveTo(cx, cy + s * 0.95f)
        path.cubicTo(cx - s * 1.35f, cy + s * 0.1f, cx - s * 0.9f, cy - s * 0.95f, cx, cy - s * 0.35f)
        path.cubicTo(cx + s * 0.9f, cy - s * 0.95f, cx + s * 1.35f, cy + s * 0.1f, cx, cy + s * 0.95f)
        path.close()
        c.drawPath(path, maskPaint)
    }
}
