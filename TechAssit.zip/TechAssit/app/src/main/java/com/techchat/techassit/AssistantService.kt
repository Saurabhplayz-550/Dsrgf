package com.techchat.techassit

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.abs

/** Foreground service: overlay eyes on top of other apps + screen capture for the AI. */
class AssistantService : Service() {

    companion object {
        const val ACTION_OVERLAY_ON = "overlay_on"
        const val ACTION_OVERLAY_OFF = "overlay_off"
        const val ACTION_PROJECTION_ON = "projection_on"
        const val ACTION_PROJECTION_OFF = "projection_off"
        const val ACTION_STOP_ALL = "stop_all"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "techassit"

        @Volatile var overlayActive = false
        @Volatile var projectionActive = false
    }

    private var wm: WindowManager? = null
    private var overlay: EyesView? = null
    private var overlayListener: ((Emotion) -> Unit)? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var lastShot: Bitmap? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AssistantEngine.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_OVERLAY_ON -> {
                ensureForeground(projectionActive)
                showOverlay()
            }
            ACTION_OVERLAY_OFF -> hideOverlay()
            ACTION_PROJECTION_ON -> {
                ensureForeground(true)
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
                if (data != null) startProjection(code, data)
            }
            ACTION_PROJECTION_OFF -> stopProjection()
            ACTION_STOP_ALL -> { hideOverlay(); stopProjection() }
        }
        checkStop()
        return START_NOT_STICKY
    }

    private fun checkStop() {
        if (!overlayActive && !projectionActive) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ---------- Foreground notification ----------

    private fun ensureForeground(withProjection: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "TechAssit", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, AssistantService::class.java).setAction(ACTION_STOP_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("TechAssit chalu hai")
            .setContentText("Aankhon par tap karke baat karo")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Band karo", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            val type = if (withProjection)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, type)
        } else if (Build.VERSION.SDK_INT >= 29 && withProjection) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(1, n)
    }

    // ---------- Overlay ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        if (overlay != null) { overlayActive = true; return }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission do", Toast.LENGTH_LONG).show()
            return
        }
        val windowManager = wm ?: return
        val v = EyesView(this).apply { showGrid = false; cols = 80; emotion = AssistantEngine.emotion }
        val l: (Emotion) -> Unit = { e -> v.emotion = e }
        AssistantEngine.listeners.add(l)

        val lp = WindowManager.LayoutParams(
            dp(240), dp(110),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(100) }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); windowManager.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) AssistantEngine.onTap(); true }
                else -> false
            }
        }
        try {
            windowManager.addView(v, lp)
        } catch (e: Exception) {
            AssistantEngine.listeners.remove(l)
            Toast.makeText(this, "Overlay error: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        overlay = v
        overlayListener = l
        overlayActive = true
        Toast.makeText(this, "Overlay chalu ho gaya", Toast.LENGTH_SHORT).show()
    }

    private fun hideOverlay() {
        overlayListener?.let { AssistantEngine.listeners.remove(it) }
        overlayListener = null
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        overlay = null
        overlayActive = false
    }

    // ---------- Screen capture ----------

    private fun startProjection(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopProjection(); checkStop() }
        }, handler)
        val dm = resources.displayMetrics
        val w = dm.widthPixels / 2
        val h = dm.heightPixels / 2
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        vdisplay = mp.createVirtualDisplay(
            "TechAssit", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        projectionActive = true
        AssistantEngine.screenProvider = { capture() }
    }

    private fun capture(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return lastShot
        try {
            val p = img.planes[0]
            val rowPad = p.rowStride - p.pixelStride * img.width
            val full = Bitmap.createBitmap(img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            val bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
            lastShot = bmp
            return bmp
        } finally {
            img.close()
        }
    }

    private fun stopProjection() {
        if (projection == null && !projectionActive) return
        AssistantEngine.screenProvider = null
        vdisplay?.release(); vdisplay = null
        reader?.close(); reader = null
        val mp = projection
        projection = null
        projectionActive = false
        lastShot = null
        try { mp?.stop() } catch (_: Exception) {}
        if (overlayActive) ensureForeground(false)
    }

    override fun onDestroy() {
        hideOverlay()
        stopProjection()
        super.onDestroy()
    }
}
