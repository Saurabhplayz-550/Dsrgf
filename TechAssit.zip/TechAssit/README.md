# TechAssit
1. Android Studio me folder open karo, Gradle sync hone do.
2. API key local.properties me GEMINI_API_KEY= ke aage hai (git me commit mat karna).
3. Phone par Run karo, mic permission do. Aankhon par tap = baat shuru.
4. Gear icon: Overlay mode / Screen dekhna.
