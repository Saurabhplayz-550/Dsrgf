package com.techchat.techassit

import android.Manifest
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var eyes: EyesView
    private val emoListener: (Emotion) -> Unit = { eyes.emotion = it }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private val projLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, AssistantService::class.java)
                    .setAction(AssistantService.ACTION_PROJECTION_ON)
                    .putExtra(AssistantService.EXTRA_CODE, r.resultCode)
                    .putExtra(AssistantService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(p.toTypedArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AssistantEngine.init(this)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        eyes = EyesView(this)
        eyes.setOnClickListener { if (hasMic()) AssistantEngine.onTap() else requestPerms() }
        root.addView(eyes, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val gear = ImageButton(this).apply {
            setImageResource(R.drawable.ic_settings)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { showSettings() }
        }
        root.addView(gear, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(12), dp(12), 0)
        })

        val hint = TextView(this).apply {
            text = "Aankhon par tap karke baat karo"
            setTextColor(0x554F9DFF)
            textSize = 12f
        }
        root.addView(hint, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ).apply { bottomMargin = dp(16) })

        setContentView(root)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        if (!hasMic()) requestPerms()
        if (AssistantEngine.apiKey().isBlank()) showKeyDialog()
    }

    private fun showVoiceDialog() {
        val names = arrayOf(
            "Kore - female, clear", "Aoede - female, soft", "Zephyr - female, bright",
            "Puck - male, upbeat", "Charon - male, calm", "Fenrir - male, energetic"
        )
        val ids = arrayOf("Kore", "Aoede", "Zephyr", "Puck", "Charon", "Fenrir")
        val cur = ids.indexOf(AssistantEngine.voice()).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Awaaz chuno")
            .setSingleChoiceItems(names, cur) { d, which ->
                AssistantEngine.setVoice(ids[which])
                Toast.makeText(this, "Awaaz: ${ids[which]}", Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .show()
    }

    private fun showKeyDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Gemini API key paste karo"
            setText(AssistantEngine.apiKey())
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("API key")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                AssistantEngine.setApiKey(input.text.toString())
                Toast.makeText(this, "Key save ho gayi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Baad me", null)
            .show()
    }

    override fun onStart() {
        super.onStart()
        AssistantEngine.listeners.add(emoListener)
        eyes.emotion = AssistantEngine.emotion
    }

    override fun onStop() {
        AssistantEngine.listeners.remove(emoListener)
        if (!AssistantService.overlayActive) AssistantEngine.stop()
        super.onStop()
    }

    private fun showSettings() {
        val items = arrayOf(
            "Overlay mode (har app par aankhein)",
            "Screen dekhna (AI ko screenshot dikhao)",
            "Device control (Accessibility)"
        )
        val checked = booleanArrayOf(
            AssistantService.overlayActive,
            AssistantService.projectionActive,
            TechAccessibilityService.instance != null
        )
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setMultiChoiceItems(items, checked) { d: DialogInterface, which: Int, on: Boolean ->
                val ok = when (which) {
                    0 -> toggleOverlay(on)
                    1 -> toggleProjection(on)
                    else -> toggleAccess(on)
                }
                if (!ok) (d as AlertDialog).listView.setItemChecked(which, false)
            }
            .setPositiveButton("Theek hai", null)
            .setNeutralButton("API key") { _, _ -> showKeyDialog() }
            .setNegativeButton("Awaaz") { _, _ -> showVoiceDialog() }
            .show()
    }

    private fun toggleOverlay(on: Boolean): Boolean {
        if (on) {
            if (!hasMic()) { requestPerms(); return false }
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay permission ON karke wapas aao", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return false
            }
            ContextCompat.startForegroundService(
                this, Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_OVERLAY_ON)
            )
        } else {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_OVERLAY_OFF))
        }
        return true
    }

    private fun toggleAccess(on: Boolean): Boolean {
        Toast.makeText(this, "List me TechAssit dhundo aur ON/OFF karo", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        return !on
    }

    private fun toggleProjection(on: Boolean): Boolean {
        if (on) {
            if (!hasMic()) { requestPerms(); return false }
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projLauncher.launch(mpm.createScreenCaptureIntent())
        } else {
            startService(Intent(this, AssistantService::class.java).setAction(AssistantService.ACTION_PROJECTION_OFF))
        }
        return true
    }
}
