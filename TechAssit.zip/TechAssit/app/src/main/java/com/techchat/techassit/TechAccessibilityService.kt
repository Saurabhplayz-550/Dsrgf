package com.techchat.techassit

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets the AI read the screen's UI elements and perform taps, typing, scrolling, back/home. */
class TechAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: TechAccessibilityService? = null
    }

    private val nodes = ArrayList<AccessibilityNodeInfo>()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    // ---------- Reading the screen ----------

    @Synchronized
    fun dump(): String {
        nodes.clear()
        val root = rootInActiveWindow ?: return "(screen padh nahi paya)"
        val sb = StringBuilder("app=${root.packageName}\n")
        walk(root, sb)
        return sb.toString().take(7000)
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || nodes.size >= 160 || !n.isVisibleToUser) return
        val text = (n.text ?: n.contentDescription)?.toString()?.replace("\n", " ")?.take(80) ?: ""
        val interactive = n.isClickable || n.isLongClickable || n.isEditable || n.isScrollable || n.isCheckable
        val skipContainer = text.isBlank() && n.childCount > 0 && !n.isEditable && !n.isScrollable
        if ((text.isNotBlank() || interactive) && !skipContainer) {
            val fl = ArrayList<String>()
            if (n.isClickable) fl.add("click")
            if (n.isLongClickable) fl.add("long")
            if (n.isEditable) fl.add("edit")
            if (n.isScrollable) fl.add("scroll")
            if (n.isCheckable) fl.add(if (n.isChecked) "checked" else "unchecked")
            val r = Rect(); n.getBoundsInScreen(r)
            sb.append("[${nodes.size}] ${n.className?.toString()?.substringAfterLast('.')} \"$text\" ")
                .append(fl.joinToString(",")).append(" @${r.centerX()},${r.centerY()}\n")
            nodes.add(n)
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), sb)
    }

    // ---------- Actions ----------

    @Synchronized
    fun click(id: Int): String {
        val node = nodes.getOrNull(id) ?: return "FAIL: id $id nahi mila"
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "OK"
            cur = cur.parent
            depth++
        }
        val r = Rect(); node.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    @Synchronized
    fun longClick(id: Int): String {
        val node = nodes.getOrNull(id) ?: return "FAIL: id $id nahi mila"
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isLongClickable && cur.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return "OK"
            cur = cur.parent
            depth++
        }
        return "FAIL"
    }

    @Synchronized
    fun type(id: Int, text: String): String {
        val node = (if (id >= 0) nodes.getOrNull(id) else rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT))
            ?: return "FAIL: text field nahi mila"
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "OK" else "FAIL"
    }

    @Synchronized
    fun enter(id: Int): String {
        if (Build.VERSION.SDK_INT < 30) return "FAIL: enter is Android me support nahi"
        val node = (if (id >= 0) nodes.getOrNull(id) else rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT))
            ?: return "FAIL: field nahi mila"
        return if (node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) "OK" else "FAIL"
    }

    fun tap(x: Float, y: Float): String = gesture(x, y, x, y, 60)

    /** finger direction */
    fun swipeDir(dir: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        return when (dir) {
            "up" -> gesture(w / 2, h * 0.72f, w / 2, h * 0.28f, 350)
            "down" -> gesture(w / 2, h * 0.28f, w / 2, h * 0.72f, 350)
            "left" -> gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 300)
            "right" -> gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 300)
            else -> "FAIL: dir galat"
        }
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): String {
        val p = Path()
        p.moveTo(x1, y1)
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        return if (dispatchGesture(g, null, null)) "OK" else "FAIL"
    }

    fun global(action: Int): String = if (performGlobalAction(action)) "OK" else "FAIL"
}
