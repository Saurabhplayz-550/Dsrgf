package com.techchat.techassit

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.net.URLEncoder

/** Executes one action requested by the AI. Returns "OK" or an error string for the AI to read. */
object DeviceControl {

    fun run(ctx: Context, a: JSONObject): String =
        try { exec(ctx, a) } catch (e: Exception) { "ERROR: ${e.message}" }

    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = TechAccessibilityService.instance ?: ctx
        c.startActivity(i)
    }

    private fun exec(ctx: Context, a: JSONObject): String {
        val svc = TechAccessibilityService.instance
        fun need(): TechAccessibilityService =
            svc ?: throw IllegalStateException("Device control (Accessibility) ON nahi hai")

        return when (val act = a.optString("a")) {
            "open_app" -> openApp(ctx, a.optString("name"))
            "open_url" -> { launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url")))); "OK" }
            "search" -> {
                val q = URLEncoder.encode(a.getString("q"), "UTF-8")
                launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q"))); "OK"
            }
            "dial" -> { launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.getString("number")))); "OK (dialer khul gaya)" }
            "alarm" -> {
                launch(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("h"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("m", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "TechAssit"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); "OK"
            }
            "timer" -> {
                launch(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("sec"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); "OK"
            }
            "flashlight" -> flash(ctx, a.optBoolean("on", true))
            "volume" -> volume(ctx, a.optString("dir"), a.optInt("pct", 50))
            "media" -> media(ctx, a.optString("key"))
            "settings" -> settings(ctx, a.optString("page"))
            "click" -> need().click(a.getInt("id"))
            "long_click" -> need().longClick(a.getInt("id"))
            "type" -> need().type(a.optInt("id", -1), a.getString("text"))
            "enter" -> need().enter(a.optInt("id", -1))
            "tap" -> need().tap(a.getDouble("x").toFloat(), a.getDouble("y").toFloat())
            "scroll" -> need().swipeDir(if (a.optString("dir") == "up") "down" else "up")
            "swipe" -> need().swipeDir(a.optString("dir"))
            "back" -> need().global(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> need().global(AccessibilityService.GLOBAL_ACTION_HOME)
            "recents" -> need().global(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "notifications" -> need().global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> need().global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            "lock" -> if (Build.VERSION.SDK_INT >= 28) need().global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) else "ERROR: support nahi"
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) need().global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) else "ERROR: support nahi"
            "wait" -> { Thread.sleep(a.optLong("ms", 1000).coerceIn(0L, 5000L)); "OK" }
            else -> "ERROR: unknown action '$act'"
        }
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
        val n = name.lowercase().trim()
        val best = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull {
                val l = it.loadLabel(pm).toString().lowercase()
                l.contains(n) || (l.length >= 3 && n.contains(l))
            }
            ?: return "ERROR: '$name' naam ka app nahi mila"
        val i = pm.getLaunchIntentForPackage(best.activityInfo.packageName) ?: return "ERROR: app khul nahi sakta"
        launch(ctx, i)
        return "OK (${best.loadLabel(pm)} khul gaya)"
    }

    private fun flash(ctx: Context, on: Boolean): String {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "ERROR: flashlight nahi hai"
        cm.setTorchMode(id, on)
        return "OK"
    }

    private fun volume(ctx: Context, dir: String, pct: Int): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val s = AudioManager.STREAM_MUSIC
        when (dir) {
            "up" -> repeat(2) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            "down" -> repeat(2) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
            "set" -> am.setStreamVolume(s, am.getStreamMaxVolume(s) * pct.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
            else -> return "ERROR: dir galat"
        }
        return "OK"
    }

    private fun media(ctx: Context, key: String): String {
        val code = when (key) {
            "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "ERROR: key galat"
        }
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "OK"
    }

    private fun settings(ctx: Context, page: String): String {
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        launch(ctx, Intent(action))
        return "OK"
    }
}
